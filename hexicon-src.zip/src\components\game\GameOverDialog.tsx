import { Button } from "@/components/ui";

import { playerName } from "@/game/names";

import { PLAYER_TAG_CLASS } from "@/lib/tileStyles";

import { Player } from "@/types/HexTile";

type GameOverDialogProps = {
  winner: Player;
  resetGame: () => void;
  /** Optional player the bot controls. */
  botPlayer?: Player;
};

/** Modal shown when the game ends, with the winner and a replay button. */
export default function GameOverDialog({
  winner,
  resetGame,
  botPlayer,
}: GameOverDialogProps) {
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="game-over-title"
      className="fixed inset-0 z-10 flex items-center justify-center bg-black/60"
    >
      <div className="flex flex-col items-center gap-4 rounded-xl border border-border bg-surface p-6 text-foreground">
        <p id="game-over-title" className="flex items-center gap-2 text-2xl">
          <span
            className={`rounded-md px-2 font-semibold ${PLAYER_TAG_CLASS[winner]}`}
          >
            {playerName(winner, botPlayer).toUpperCase()}
          </span>
          <span>wins</span>
        </p>
        <Button autoFocus onClick={resetGame}>
          PLAY AGAIN
        </Button>
      </div>
    </div>
  );
}
